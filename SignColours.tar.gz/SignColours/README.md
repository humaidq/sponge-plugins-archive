# Sign Colours
A lightweight Sponge plugin which allows you to create coloured signs.

![screenshot](https://i.imgur.com/jTSnmH9.png)

## Permissions
* signcolours.colour

## How to build
With Maven 3
`mvn clean install`