Chat Limiter [![Build Status](https://api.travis-ci.org/hmksq/ChatLimiter.svg?branch=master)](https://travis-ci.org/hmksq/ChatLimiter)
============
**Chat Limiter is relying on SpongeAPI which is currently not stable**  
Chat Limiter is a lightweight Sponge plugin which allows you to limit the rate of chat messages and commands. It is licensed under the [MIT License].

## Permissions
* chatlimiter.bypass

## Configuration
```
cooldown {
    # Cooldown Message, leave empty quotes to disable (colour code supported)
    message="&cYou have to wait &e%s &cseconds to send another message!"
    # Cooldown time in milliseconds
    timeMs=3000
}
```

## Prerequisites
* [Java] 8

## Cloning and Building
1. `git clone https://github.com/hmksq/ChatLimiter.git`
2. `./gradlew build`
3. Compiled JAR files will be in `./build/libs`.

## Contributing
We appreciate your contributions! We follow [Sponge's Contribution Guidelines]!

[MIT License]: https://tldrlegal.com/license/mit-license
[Java]: http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
[Sponge's Contribution Guidelines]: https://docs.spongepowered.org/en/contributing/guidelines.html
