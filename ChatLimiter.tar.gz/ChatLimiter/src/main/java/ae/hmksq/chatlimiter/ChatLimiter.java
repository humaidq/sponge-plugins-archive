/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2015 Sheikh Humaid AlQassimi
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package ae.hmksq.chatlimiter;

import ninja.leaping.configurate.commented.CommentedConfigurationNode;
import ninja.leaping.configurate.loader.ConfigurationLoader;
import org.slf4j.Logger;
import org.spongepowered.api.entity.living.player.Player;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.command.MessageSinkEvent;
import org.spongepowered.api.event.command.SendCommandEvent;
import org.spongepowered.api.event.game.state.GameInitializationEvent;
import org.spongepowered.api.plugin.Plugin;
import org.spongepowered.api.service.config.DefaultConfig;
import org.spongepowered.api.text.Texts;
import org.spongepowered.api.util.TextMessageException;

import javax.inject.Inject;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Plugin(id = "chatlimiter", name = "Chat Limiter", version = "0.2.3-1")
public class ChatLimiter {

    private HashMap<UUID, Integer> cooldownPlayers = new HashMap<UUID, Integer>();
    private int cooldownTime = 3000;
    private String cooldownMessage = "&cYou have to wait &e%s &cseconds to send another message!";
    private boolean commandCooldown = false;

    @Inject
    private Logger logger;

    @Inject
    @DefaultConfig(sharedRoot = true)
    private File configuration;

    @Inject
    @DefaultConfig(sharedRoot = true)
    private ConfigurationLoader<CommentedConfigurationNode> configurationLoader;

    private CommentedConfigurationNode configurationNode;

    @Listener
    public void onInit(GameInitializationEvent event) {
        try {
            if (!configuration.exists()) {
                configuration.createNewFile();
                configurationNode = configurationLoader.load();
                configurationNode.getNode("cooldown", "message").setValue("&cYou have to wait &e%s &cseconds to send another message or command!").setComment("Cooldown Message, leave empty quotes to disable (colour code support depreciated)");
                configurationNode.getNode("cooldown", "timeMs").setValue(3000).setComment("Cooldown time in milliseconds");
                configurationNode.getNode("cooldown", "commandcooldown").setValue(false).setComment("Enables or disables cooldowns for commands, the cooldown time is the same as the chat");
                configurationLoader.save(configurationNode);
            }

            configurationNode = configurationLoader.load();

            cooldownMessage = configurationNode.getNode("cooldown", "message").getString();
            cooldownTime = configurationNode.getNode("cooldown", "timeMs").getInt();
            commandCooldown = configurationNode.getNode("cooldown", "commandcooldown").getBoolean();
        } catch (IOException e) {
            logger.error("Cannot load or create configuration file! Is it outdated?");
            e.printStackTrace();
        }

        event.getGame().getScheduler().createTaskBuilder().execute(() -> {
            for (Map.Entry<UUID, Integer> entry : cooldownPlayers.entrySet()) {
                UUID uuid = entry.getKey();
                Integer timeLeft = entry.getValue();
                if (timeLeft <= 1) {
                    cooldownPlayers.remove(uuid);
                } else {
                    cooldownPlayers.put(uuid, timeLeft - 50);
                }
            }
        }).interval(50, TimeUnit.MILLISECONDS).name("Chat Limiter - Countdown tick").submit(this);
    }

    /**
     * Checks if the player has a cooldown or not
     *
     * @param playerOptional The player to check
     * @return True if the player has a cooldown
     */
    private Optional<Boolean> hasCooldown(Optional<Player> playerOptional) {
        if (!playerOptional.isPresent()) {
            return Optional.empty();
        }

        try {
            Player player = playerOptional.get();

            if (player.hasPermission("chatlimiter.bypass")) {
                return Optional.of(false);
            }

            if (cooldownPlayers.containsKey(player.getUniqueId())) {
                return Optional.of(true);
            } else {
                return Optional.of(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return Optional.empty();
    }

    @Listener
    public void sendCommand(SendCommandEvent event) throws TextMessageException {
        if (!commandCooldown) {
            return;
        }

        Optional<Player> playerOpt = event.getCause().first(Player.class);

        if (!playerOpt.isPresent()) {
            return;
        }

        Optional<Boolean> cResult = hasCooldown(playerOpt);

        if (!cResult.isPresent()) {
            return;
        }

        Player player = playerOpt.get();

        if (cResult.get()) {
            if (!cooldownMessage.isEmpty()) {
                player.sendMessage(Texts.legacy('&').from(String.format(cooldownMessage, cooldownPlayers.get(player.getUniqueId()) / 1000 + 1)));
            }
            logger.info(player.getName() + " tried to send a command too quickly!");
            event.setCancelled(true);
        } else {
            cooldownPlayers.put(player.getUniqueId(), cooldownTime);
        }
    }

    @Listener
    public void sendChat(MessageSinkEvent.Chat event) throws TextMessageException {
        Optional<Player> playerOpt = event.getCause().first(Player.class);

        if (!playerOpt.isPresent()) {
            return;
        }

        Optional<Boolean> cResult = hasCooldown(playerOpt);

        if (!cResult.isPresent()) {
            return;
        }

        Player player = playerOpt.get();

        if (cResult.get()) {
            if (!cooldownMessage.isEmpty()) {
                player.sendMessage(Texts.legacy('&').from(String.format(cooldownMessage, cooldownPlayers.get(player.getUniqueId()) / 1000 + 1)));
            }
            logger.info(player.getName() + " tried to send a chat message too quickly!");
            event.setCancelled(true);
        } else {
            cooldownPlayers.put(player.getUniqueId(), cooldownTime);
        }
    }

}
