/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2015 Sheikh Humaid AlQassimi
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package ae.hmksq.playerlogger;

import org.slf4j.Logger;
import org.spongepowered.api.entity.living.player.Player;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.command.MessageSinkEvent;
import org.spongepowered.api.event.command.SendCommandEvent;
import org.spongepowered.api.event.entity.DestructEntityEvent;
import org.spongepowered.api.event.game.state.GameInitializationEvent;
import org.spongepowered.api.event.network.ClientConnectionEvent;
import org.spongepowered.api.plugin.Plugin;
import org.spongepowered.api.text.Texts;

import javax.inject.Inject;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

@Plugin(id = "playerlogger", name = "Player Logger", version = "0.1.0")
public class PlayerLoggerSponge {

    @Inject
    private Logger logger;

    @Listener
    public void onInit(GameInitializationEvent event) {
        if (!new File("playerlogs/").exists()) {
            new File("playerlogs/").mkdir();
        }
    }

    @Listener
    public void onJoin(ClientConnectionEvent.Login event) {
        Optional<Player> playerOpt = event.getCause().first(Player.class);
        logToFile(playerOpt, this.getPlayerNameFromOptional(playerOpt) + " logging in [" + event.getConnection().getAddress().getHostName() + "]");
    }

    @Listener
    public void onJoin(ClientConnectionEvent.Join event) {
        Optional<Player> playerOpt = event.getCause().first(Player.class);
        logToFile(playerOpt, this.getPlayerNameFromOptional(playerOpt) + " joined the server");
    }

    @Listener
    public void onLeave(ClientConnectionEvent.Disconnect event) {
        Optional<Player> playerOpt = event.getCause().first(Player.class);
        logToFile(playerOpt, this.getPlayerNameFromOptional(playerOpt) + " left the server");
    }

    @Listener
    public void onChat(MessageSinkEvent event) {
        Optional<Player> playerOpt = event.getCause().first(Player.class);
        logToFile(playerOpt, Texts.toPlain(event.getMessage()), true);
    }

    @Listener
    public void onCommand(SendCommandEvent event) {
        Optional<Player> playerOpt = event.getCause().first(Player.class);
        logToFile(playerOpt, this.getPlayerNameFromOptional(playerOpt) + " ran /" + event.getCommand() + "", true);
    }

    @Listener
    public void onDeath(DestructEntityEvent event) {
        if (event.getTargetEntity() instanceof Player) {
            logToFile(Optional.of((Player) event.getTargetEntity()), ((Player) event.getTargetEntity()).getName() + " died");
        }
    }

    private String getPlayerNameFromOptional(Optional<Player> playerOpt) {
        if (playerOpt.isPresent())
            return playerOpt.get().getName();
        else
            return "~NPC";
    }

    private void logToFile(Optional<Player> player, String log) {
        logToFile(player, log, false);
    }

    private void logToFile(Optional<Player> player, String log, boolean chat) {
        try {
            String nameInFile = "~NPC";
            if (player.isPresent()) {
                nameInFile = player.get().getUniqueId().toString();
            }
            File file = new File("playerlogs/" + nameInFile + "_event.log");

            if (chat && player.isPresent())
                file = new File("playerlogs/" + nameInFile + "_chat.log");
            else if (chat && !player.isPresent())
                file = new File("playerlogs/messagesink.log");

            boolean newFile = false;
            if (!file.exists()) {
                file.createNewFile();
                newFile = true;
            }
            Writer logFile = new BufferedWriter(new FileWriter(file, true));
            String timestamp = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss] ").format(new Date());
            if (newFile) {
                if (chat)
                    if (player.isPresent())
                        logFile.write("# " + getPlayerNameFromOptional(player) + "'s log file for chat messages and commands\n\n");
                    else
                        logFile.write("# Any message that its source is not a Player or an NPC\n\n");
                else
                    logFile.write("# " + getPlayerNameFromOptional(player) + "'s log file for events\n\n");
            }
            logFile.write(timestamp + log + "\n");
            logFile.close();
        } catch (Exception ex) {
            logger.error("Failed to log player action to file!");
            ex.printStackTrace();
        }
    }

}
