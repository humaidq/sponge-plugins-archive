Player Logger
=============
A lightweight Sponge plugin which logs player logins (with IPs), chat messages, commands, deaths, block breaking attempt in protected areas and portal entries. And more! It is licensed under the [MIT License].
## Logs folder
When starting the server with the plugin for the first time, the plugin will generated a `playerlogs/` folder.  
In there, it will store files named `<uuid>_chat.log` and `<uuid>_events.log`.

## Prerequisites
* [Java] 8

## Cloning and Building
1. `git clone https://github.com/hmksq/PlayerLogger.git`
2. `./gradlew build`
3. Compiled JAR files will be in `./build/libs`.

## Contributing
We appreciate your contributions! We follow [Sponge's Contribution Guidelines]!

[MIT License]: https://tldrlegal.com/license/mit-license
[Java]: http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
[Sponge's Contribution Guidelines]: https://docs.spongepowered.org/en/contributing/guidelines.html
